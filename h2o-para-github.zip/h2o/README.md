# H2O — prototipo web

Aplicación web para registrar el consumo de agua con un sticker NFC en tu botella de siempre.
Proyecto TEI301 · UAI · Grupo 9.

## Estado: Módulo 4 (NFC)

- **Mis botellas**: crear, editar, eliminar y elegir la botella en uso (Módulo 3).
- **NFC**: cada botella tiene un enlace fijo `https://<dominio>/nfc/<código>` para grabar en el sticker
  (botón **NFC** en cada botella). Al abrirlo se muestra "Registrar 250 ml"; nada se guarda sin confirmar.

## Módulo 2 (registro manual y dashboard funcional)

- Registro manual (150 / 250 / 500 / otra cantidad) con confirmación.
- Dashboard real: total del día, meta, %, barra, cuánto falta y mensaje según avance.
- Historial del día con eliminación (pide confirmación) y resumen semanal.
- Meta diaria configurable (2.000 ml por defecto).
- Datos guardados en el navegador (`localStorage`), por fecha local del celular.
- Sigue con datos de ejemplo: **Mis botellas** y la tarjeta "Botella actual".

### Dónde están los datos

`lib/storage.ts` es el único archivo que lee o escribe datos. Para pasar a una base de
datos (Etapa 2) se reemplaza ese archivo; las pantallas no cambian.

Para borrar todos los datos de prueba: en el navegador, herramientas de desarrollador →
Application → Local Storage → eliminar las claves `h2o:v1:*`.

### Pruebas automáticas

`pruebas/test_modulo2.py`, `test_modulo3.py` y `test_modulo4.py` (Python + Playwright) recorren la app
en una pantalla de celular con la app corriendo en `localhost:3000`.

## Cómo abrirla en tu computador

Necesitas [Node.js](https://nodejs.org) versión 20 o superior (descarga la versión "LTS").

```bash
cd h2o
npm install        # solo la primera vez (descarga las dependencias)
npm run dev        # inicia el servidor de desarrollo
```

Abre http://localhost:3000 en el navegador.

### Verla en tu celular (misma red Wi-Fi que el computador)

```bash
npm run dev -- -H 0.0.0.0
```

En el celular, abre `http://<IP-de-tu-computador>:3000`. La IP aparece en la terminal como "Network".
(Para el NFC esto no basta: el sticker necesita una dirección pública con HTTPS → se publica en Vercel.)

## Estructura

```
app/            pantallas (cada carpeta = una sección)
  page.tsx        Inicio (dashboard)
  historial/      Historial
  botellas/       Mis botellas
  metas/          Metas
components/     piezas reutilizables (navegación, logo, panel de registro…)
lib/            tipos de datos, formato de números y datos de ejemplo
app/globals.css colores de la marca (editar aquí para cambiar la paleta)
```
